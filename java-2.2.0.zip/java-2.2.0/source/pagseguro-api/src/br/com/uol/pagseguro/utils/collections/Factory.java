package br.com.uol.pagseguro.utils.collections;

public interface Factory<T> {

    T create();

}
